package com.example.customerAccount.DTO;

import lombok.Data;

@Data
public class DebitDTO
{
    private Long id;
    private Long pin;

    
}
