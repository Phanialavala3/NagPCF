package com.example.customerAccount.Controller;

import com.example.customerAccount.DAO.CustomerDAO;
import com.example.customerAccount.DTO.CustomerDTO;
import com.example.customerAccount.Entity.CustomerEntity;
import com.example.customerAccount.Service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
    @Autowired
    private BankService bankService;

    @PostMapping("/registration")
    public CustomerDAO registration(@RequestBody CustomerDTO customer){
        return  bankService.saveCustomer(customer);
    }
}
