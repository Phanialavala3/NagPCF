package com.example.customerAccount.DAO;

import lombok.Data;

@Data
public class CreditDAO
{
    private Long id;
    private Long creditId;

    
}
