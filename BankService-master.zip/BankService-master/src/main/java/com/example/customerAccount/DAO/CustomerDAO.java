package com.example.customerAccount.DAO;

import lombok.Data;

@Data
public class CustomerDAO
{
    private Long id;
    private String status;

}
