package com.example.customerAccount.DAO;

import lombok.Data;

@Data
public class DebitDAO
{
    private Long id;
    private Long debitId;

   
}
