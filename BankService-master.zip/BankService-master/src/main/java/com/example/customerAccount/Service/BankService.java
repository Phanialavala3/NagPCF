package com.example.customerAccount.Service;

import com.example.customerAccount.DAO.CustomerDAO;
import com.example.customerAccount.DTO.CustomerDTO;
import com.example.customerAccount.Entity.CustomerEntity;
import com.example.customerAccount.Repositories.CustomerRepository;


import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BankService {

    private CustomerRepository customerRepository;
    private CustomerDAO customerDAO;
    private ModelMapper modelMapper;

    public BankService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
        this.customerDAO = new CustomerDAO();
        this.modelMapper = new ModelMapper();
    }

    public CustomerDAO saveCustomer(CustomerDTO customer)
    {
    	CustomerEntity customerEntity;
    	customerEntity = modelMapper.map(customer, CustomerEntity.class);
    	System.out.println("Customer" + customerEntity);
        customerRepository.save(customerEntity);
        Optional<CustomerEntity> customerPresent=customerRepository.findById(customerEntity.getCustomerId());
        if(customerPresent.isPresent()){
            CustomerEntity newCustomer;
            newCustomer=customerPresent.get();
            customerDAO.setId(newCustomer.getCustomerId());
            customerDAO.setStatus("Success");
            return  customerDAO;
        }
        else
        {
            throw new RuntimeException("Error in Saving Customer . Please try again");
        }

    }
}
