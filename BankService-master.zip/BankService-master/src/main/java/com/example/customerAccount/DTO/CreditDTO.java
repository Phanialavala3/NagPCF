package com.example.customerAccount.DTO;

import lombok.Data;

@Data
public class CreditDTO
{
    private Long creditId;
    private Long creditZip;

   
}
