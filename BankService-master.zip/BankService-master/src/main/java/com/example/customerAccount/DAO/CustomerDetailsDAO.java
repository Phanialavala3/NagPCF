package com.example.customerAccount.DAO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
public class CustomerDetailsDAO {
    private long id;

    private String Name;
    private String Address1line;
    private String Address2line;
    private String city;
    private String state;
    private Long zip;
    private Long phone;
    private String email;
    private String Debit;
    private String Credit;

}